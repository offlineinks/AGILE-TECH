					  Circular Progress Bar
 Circular ProgressBar is a custom control for WinForm with animation

=====================================================================

USAGE
	Use toolbox to add the control to your forms.